#pragma once
#include "globals.h"
#include <time.h>

// This just gets rid of Intellisense squiggles for setenv() and tzset()
_VOID _EXFUN(tzset, (_VOID));
int _EXFUN(setenv, (const char *__string, const char *__value, int __overwrite));

namespace calendar {

const char *ntpServer        = "pool.ntp.org";
const long gmtOffset_sec     = 0;
const int daylightOffset_sec = 3600;

// Global time (set when connected to WiFi)
struct tm timeinfo;

// Numeric values of current date, 2 digits
uint8_t currYear;
uint8_t currMonth;
uint8_t currDay;

// String versions of the date (to match SD card) only used to create above integer versions
char dateYear[3];
char dateMonth[3];
char dateDay[3];

// Keep current (actual) hour and minutes so we can calculate sleep time
uint8_t nowHour;
uint8_t nowMins;

struct binNextCollection {
    char binType;
    bool notFound;
    int daysUntilCollection;
    int binCollectionWeekDay;
    int binCollectionMonthDate;
    int binCollectionMonth;
} BlackCollection, GreenCollection, PurpleCollection;

// Last updated date and time string
char currentDateTime[50];

// Date comparison value
int daysSinceYearStart;

// Days of week 0 - 6
const char *daysOfWeek[] = {"SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"};

// Months 0 - 11
const char *months[] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};

// Accepts new yy,MM,dd and returns day of week and days since beginning of year
int anyDate(uint8_t newYear, uint8_t newMonth, uint8_t newDay, uint8_t &dayOfWeek) {

    // Get local date/time into tm
    getLocalTime(&timeinfo);

    // Adjust the date as required
    timeinfo.tm_mday = newDay;         // Day is 1 - 31
    timeinfo.tm_mon  = newMonth - 1;   // Month is 0 - 11
    timeinfo.tm_year = newYear - 1900; // Year is minus 1900

    // Convert/update the date information
    mktime(&timeinfo);
    if (ARDUHAL_LOG_LEVEL == ARDUHAL_LOG_LEVEL_VERBOSE) {
        Serial.println(&timeinfo, "%A, %B %d %Y %H:%M:%S");
    }

    // Optional return parameter
    dayOfWeek = timeinfo.tm_wday;

    // Days since year start 0-366 in ascii string format
    char dateBuffer[10];
    strftime(dateBuffer, 10, "%j", &timeinfo);
    log_v("Days since '%s' beginning of year: %d", dateBuffer, atoi(dateBuffer));

    // Return as int for easy comparison
    return atoi(dateBuffer);
}

// for the bin-type find the next collection today (might be today)
void getNextCollectionDay(char binType) {

    if (binType != 'P' && binType != 'B' && binType != 'G') {
        log_e("Invalid bin type: %c", binType);
        return;
    }

    // Read the array (vector) until we get a 'matching' (not greater than) today's date for bin type
    log_v("Match found: Year %s, Month %s, Day %s", dateYear, dateMonth, dateDay);

    // Day of week of collection
    uint8_t dayOfBinCollection;

    // Traverse the array for the correct bin type (they are in date order)
    for (auto binDate : data::binCalendar) {
        if (binDate.binType == binType) {
            log_v("Checking collection date: %02d/%02d/%02d", binDate.binYear, binDate.binMonth, binDate.binMonthDate);

            // Days rollover. If calendar year is > current year then add 365 days
            int yearRolloverOffset = 0;
            if (binDate.binYear > currYear) {
                yearRolloverOffset = 365;
            }

            // For this bin type, is the date in the future (compared to today)? Compare days since year start.
            int binCollectionDaysSinceYearStart = anyDate(binDate.binYear, binDate.binMonth, binDate.binMonthDate, dayOfBinCollection);

            if (binCollectionDaysSinceYearStart + yearRolloverOffset >= daysSinceYearStart) {
                log_i("FOUND: %c %02d/%02d/%02d (%s) %d/%d", binDate.binType, binDate.binYear, binDate.binMonth, binDate.binMonthDate, daysOfWeek[dayOfBinCollection], daysSinceYearStart, (yearRolloverOffset + binCollectionDaysSinceYearStart));
                switch (binType) {
                    case 'P':
                        PurpleCollection.binType                = binType;
                        PurpleCollection.daysUntilCollection    = yearRolloverOffset + binCollectionDaysSinceYearStart - daysSinceYearStart;
                        PurpleCollection.binCollectionWeekDay   = dayOfBinCollection;
                        PurpleCollection.binCollectionMonthDate = binDate.binMonthDate;
                        PurpleCollection.binCollectionMonth     = binDate.binMonth;
                        break;
                    case 'G':
                        GreenCollection.binType                = binType;
                        GreenCollection.daysUntilCollection    = yearRolloverOffset + binCollectionDaysSinceYearStart - daysSinceYearStart;
                        GreenCollection.binCollectionWeekDay   = dayOfBinCollection;
                        GreenCollection.binCollectionMonthDate = binDate.binMonthDate;
                        GreenCollection.binCollectionMonth     = binDate.binMonth;
                        break;
                    case 'B':
                        BlackCollection.binType                = binType;
                        BlackCollection.daysUntilCollection    = yearRolloverOffset + binCollectionDaysSinceYearStart - daysSinceYearStart;
                        BlackCollection.binCollectionWeekDay   = dayOfBinCollection;
                        BlackCollection.binCollectionMonthDate = binDate.binMonthDate;
                        BlackCollection.binCollectionMonth     = binDate.binMonth;
                        break;
                }
                // No need to process further calendar dates for this bin type
                break;
            } else {
                // Ignore this aged date
                log_v("Ignored: %c %02d/%02d/%02d (%s) %d/%d", binDate.binType, binDate.binYear, binDate.binMonth, binDate.binMonthDate, daysOfWeek[dayOfBinCollection], daysSinceYearStart, (yearRolloverOffset + binCollectionDaysSinceYearStart));
                continue;
            }
        }
    }
}

void printLocalTime() {
    // Current date/time is?
    // Serial.println(&timeinfo, "Local time: %a, %d %b %Y %H:%M:%S %p");

    // Current date/time for last update message
    strftime(currentDateTime, 100, "%a %d %b %Y %H:%M:%S %p", &timeinfo);
    log_i("%s", currentDateTime);

    // Extract 2-digit parts of the date
    strftime(dateYear, 3, "%y", &timeinfo);
    strftime(dateMonth, 3, "%m", &timeinfo);
    strftime(dateDay, 3, "%d", &timeinfo);
    log_v("Extracted character date as Year:%s Month:%s Day:%s", dateYear, dateMonth, dateDay);

    // Convert chars to global uint8_t variables
    currYear  = atoi(dateYear);
    currMonth = atoi(dateMonth);
    currDay   = atoi(dateDay);

    // Get days since actual year start
    char buffer[5];
    strftime(buffer, 5, "%j", &timeinfo);
    daysSinceYearStart = atoi(buffer);
    log_v("Days since current year start: %d", daysSinceYearStart);
}

bool setTimeZone() {

    /*
        See https://github.com/G6EJD/ESP32-Time-Services-and-SETENV-variable/blob/master/ESP32_Time_and_SETENV.ino
        for details of setenv() and how to specify daylight saving months
    */

    // Init and get the time
    // configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
    configTime(0, 0, ntpServer);

    // Set the DST periods
    setenv("TZ", "GMT0BST,M3.5.0/01,M10.5.0/02", 1);
    tzset();

    // Get local time
    if (!getLocalTime(&timeinfo, 10000U)) {
        log_e("Failed to obtain current date and time");
        return false;
    } else {
        // Get the local time again to workaround the time discrepancy
        delay(1000);
        getLocalTime(&timeinfo, 10000U);
    }

    // To get here we MUST have retrieved the current date/time successfully (albeit inaccurately)
    printLocalTime();

    // Keep actual hour/mins so we can calculate sleep time when all is done
    nowHour = timeinfo.tm_hour;
    nowMins = timeinfo.tm_min;

    // All done
    return true;
}
} // namespace calendar