#pragma once
#include "Arduino.h"
#include "calendarHelper.h"
#include <WiFi.h>
#include <WiFiMulti.h>
#include "time.h"

// Allows brown out detected to be dis/enabled
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

namespace wifi {

const char* ssid     = "AresbyMaster";
const char* password = "xxxxxxx";

// Set Static IP address
// IPAddress local_IP(192, 168, 1, 184);

// Set Gateway IP address
// IPAddress gateway(192, 168, 1, 254);
// IPAddress subnet(255, 255, 0, 0);
// IPAddress primaryDNS(8, 8, 8, 8);   // optional
// IPAddress secondaryDNS(8, 8, 4, 4); // optional

/* Conversion factor for micro seconds to seconds */
#define uS_TO_S_FACTOR 1000000ULL

/* Time ESP32 will go to sleep (in seconds) */
#define TIME_TO_SLEEP (3600 * 12)

bool setupWiFi() {
    // Disable brown out detector. Note 200-300mA required for Wi-Fi (for just one second or so)
    // WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0); // disable BO detector

    // Configures static IP address
    // if (!WiFi.config(local_IP, gateway, subnet, primaryDNS, secondaryDNS)) {
    //     log_e("WiFi static address %s failed to configure", local_IP.toString());
    // } else {
    //     log_d("WiFi static address %s configured", local_IP.toString().c_str());
    // }

    // WiFi retry attempts
    unsigned long wifiMillis             = millis();
    int connectCnt                       = 0;
    constexpr uint8_t maxConnectAttempts = 5;
    constexpr uint8_t secondsTimeOut     = 60;

    // Start connection attempt to any of the acceptable Wi-Fi networks
    WiFi.begin(ssid, password);
    // WiFiMulti wifiMulti;
    // wifiMulti.addAP("Greypuss", "mrSeal89");
    // wifiMulti.addAP("AresbyMaster", "mrSeal89");

    // Connect to Wi-Fi
    log_d("Attempting to connect to SSID %s...", ssid);
    // while (wifiMulti.run() != WL_CONNECTED && connectCnt < maxConnectAttempts) {
    while (WiFi.status() != WL_CONNECTED && connectCnt < maxConnectAttempts) {
        delay(500);
        Serial.print(".");

        // Attempt for X seconds to connect to WiFi
        if (millis() - wifiMillis > (secondsTimeOut * 1000)) {
            wifiMillis = millis();
            connectCnt++;

            // Max attempts reached? Abort!
            if (connectCnt >= maxConnectAttempts) {
                globals::fatalError = true;
                return false;
            }
            log_w("Retry: connecting to SSID %s, attempt %d", ssid, ++connectCnt);
        }
    } // repeat while not connected and less than X attempts

    log_i("Connected to WiFi network %s", WiFi.SSID().c_str());

    /*
    while (WiFi.status() != WL_CONNECTED && connectCnt < maxConnectAttempts) {
        delay(500);
        Serial.print(".");

        // Attempt for X seconds to connect to WiFi
        if (millis() - wifiMillis > (secondsTimeOut * 1000)) {
            wifiMillis = millis();
            connectCnt++;

            // Max attempts reached? Abort!
            if (connectCnt >= maxConnectAttempts) {
                globals::fatalError = true;
                return false;
            }
            log_w("Retry: connecting to WiFi, attempt %d", ++connectCnt);
        }
    } // repeat while not connected and less than X attempts
    */

    // To get here we MUST have connected (within X attempts)
    log_i("WiFi connected (MAC address %s)", WiFi.macAddress().c_str());

    // WiFi required to get current date/time etc. Call this once to prevent memory leaks.
    uint8_t retryCnt = 0;
    while (!calendar::setTimeZone()) {
        retryCnt++;
        if (retryCnt > 5) {
            // We couldn't ge the current date/time.
            globals::fatalError = true;
            return false;
        }
        log_w("Unable to get date/time, retry attempt %d", retryCnt);
        delay(5000);
    }

    // All done
    return true;
}

// Disconnect WiFi when it's no longer needed, saves power
void switchOffWiFi() {
    log_i("Disconnecting from WiFi");
    WiFi.disconnect(true);
    WiFi.mode(WIFI_OFF);
}

// We need to sleep until 2am (or whatever time)
auto getSecondsUntil(bool isFatalError) -> unsigned long long {

    // Sleep time depends on error condition
    unsigned long secsToSleep;

    if (isFatalError) {
        secsToSleep = (WIFI_RETRY_INTERVAL_SECONDS);
    } else {
        // Complete hours from now until 2am tomorrow
        int hoursToSleep = 2 + (24 - (calendar::nowHour + 1));

        // Convert full hours to mins plus remaining mins this hour
        int minsToSleep = (hoursToSleep * 60) + (60 - calendar::nowMins);

        // Convert to seconds
        secsToSleep = minsToSleep * 60;
    }

    log_i("Sleep time is about %5.2f hours", float(secsToSleep / 3600.0f));
    return (secsToSleep * uS_TO_S_FACTOR);
}

// Sleep for TIME_TO_SLEEP seconds
void goToSleep(bool isFatalError) {

    // How much to sleep from "now" until next wake time?
    unsigned long long uS_To_Sleep = getSecondsUntil(isFatalError);
    log_w("Goodnight!\n");

    // Turn off power to screen (saves 25-30uA)
    digitalWrite(eINK_ENABLE, LOW);

    // Night night!
    esp_sleep_enable_timer_wakeup(uS_To_Sleep);
    //esp_sleep_enable_timer_wakeup(60 * 60 * uS_TO_S_FACTOR);
    esp_deep_sleep_start();
}

} // namespace wifi