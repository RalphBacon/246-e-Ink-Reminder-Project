#pragma once
#include "Arduino.h"

// Using SPI to talk to the SD card / LittleFS
#include "Wire.h"

// eInk library from Adafruit 2.13" screen 212 x 104 Tri-color
// (Newer model of this screen is 250 x 122 resolution)
#include "Adafruit_EPD.h"

// Are we using SPIFFS or LITTLEFS? Comment out next line for SPIFFS. Uncomment for LITTLEFS.
// #define SPIFFS LITTLEFS

// SPIFFS or LITTLEFS (in-memory SPI File System) replacement
#ifndef SPIFFS
#include "SPIFFS.h"
#else
#include "LITTLEFS.h"
#endif

// Utility to write to (pseudo) EEPROM
#include <Preferences.h>

// Which board is this for?
#ifdef ESP32
#define SRAM_CS 32
#define EPD_CS 5
#define EPD_DC 33
/* Plus the standard SPI connections :
    SCLK 18
    MISO 19
    MOSI 23

    These are defined in .platformio\packages\framework-arduinoespressif32\variants\esp32
*/
#define EPD_RESET 26 // can set to -1 and share with microcontroller Reset!
#define EPD_BUSY 27  // can set to -1 to not use a pin (will wait a fixed delay)
#endif

#if defined(__AVR_ATmega328P__)
#define EPD_CS 10
#define EPD_DC 9
#define SRAM_CS 8
/* Plus the standard SPI connections :
    SCLK 13
    MISO 12
    MOSI 11
*/
#define EPD_RESET 5 // can set to -1 and share with microcontroller Reset!
#define EPD_BUSY 6  // can set to -1 to not use a pin (will wait a fixed delay)
#endif

namespace globals {

// EEPROM writing routines (eg: remembers parameters)
Preferences preferences;

// Standard day of collection 0=Sunday - 6=Saturday
#define COLLECTION_DAY 1

// Bin colours
#define BLACK_BIN_HDR "Black"
#define GREEN_BIN_HDR "Green"
#define PURPLE_BIN_HDR "Purple"

// eINK enable power (via Si4599 dual MOSFET)
#define eINK_ENABLE 15

// If there is a fatal error, sleep for less time
bool fatalError = false;
#define WIFI_RETRY_INTERVAL_SECONDS 1800

} // namespace globals