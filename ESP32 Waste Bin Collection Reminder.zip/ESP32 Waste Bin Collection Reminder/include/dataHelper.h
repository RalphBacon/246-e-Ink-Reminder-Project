#pragma once
#include "Arduino.h"
#include "globals.h"
#include "FS.h"
#include "SD.h"
#include "SPI.h"

namespace data {

// Bin collection timetable
struct binTimeTable {
    char binType;
    int binYear;
    int binMonth;
    int binMonthDate;
};

// Use a vector not an array so we can just increase the size as required
std::vector<binTimeTable> binCalendar;

// Read the data from LITTLEFS and populate vector array
bool populateCalendarArray() {
    log_i("Powering up SD card / eInk screen");
    pinMode(eINK_ENABLE, OUTPUT);
    digitalWrite(eINK_ENABLE, HIGH);

    // Initialise LITTLEFS system
    if (!SPIFFS.begin(false)) {
        // TODO: display smthg on screen
        log_e("SPIFFS/LITTLEFS Mount Failed. STOPPED.");
        return false;
    } else {
        log_i("SPIFFS/LITTLEFS system mounted SUCCESSFULLY.");
    }

    // SD card CS pin
    pinMode(25, OUTPUT);

    // TODO: If SD card present with (new) bindates.txt file, copy it to LITTLEFS partition
    // SPI.begin(SCK, MISO, MOSI, 25);
    if (!SD.begin(25)) {
        log_e("SD: Cannot mount SD card (GPIO pin 25)");
    } else {
        log_v("SD: initialised on pin 25");
        if (SD.exists("/bindates.txt")) {
            log_i("Copying SD card file 'bindates.txt' to LittleFS");

            size_t bytesToRead;
            uint8_t buf[1024];
            File origFile = SD.open("/bindates.txt");
            File destFile = SPIFFS.open("/bindates.txt", "w");
            while ((bytesToRead = origFile.read(buf, sizeof(buf))) > 0) {
                destFile.write(buf, bytesToRead);
            }
            origFile.close();
            destFile.close();

            log_i("Deleting SD card file 'bindates.txt'");
            SD.remove("/bindates.txt");
        } else {
            // No (new) bin data file found
            log_i("No new 'bindates.txt' file found on SD card");
        }
    }

    File myFile = SPIFFS.open("/bindates.txt");
    if (myFile) {
        // format is <char:1>bintype<char:2>dayofmonth<char:2>month
        log_v("LITTLEFS Found 'bindates.txt' file");
        char buffer[10];

        while (myFile.available()) {
            // Bin Type
            char binType = myFile.read();

            // Year
            myFile.readBytes(buffer, 2);
            int binYear = atoi(buffer);

            // Month
            myFile.readBytes(buffer, 2);
            int binMonth = atoi(buffer);

            // Day of month
            myFile.readBytes(buffer, 2);
            int binDay = atoi(buffer);

            // Ignore the CR/LF pair at the end of every line
            myFile.readBytes(buffer, 2);

            log_v("Bin type %c on %d year, %d month, %d day", binType, binYear, binMonth, binDay);

            // Add to array/vector
            binCalendar.insert(binCalendar.end(), {binType, binYear, binMonth, binDay});
        }
        myFile.close();

        // Entire calendar (vector)
        log_d("Total calendar entries: %d", binCalendar.size());
#if ARDUHAL_LOG_LEVEL == ARDUHAL_LOG_LEVEL_VERBOSE
        for (auto cnt = 0; cnt < binCalendar.size(); cnt++) {
            binTimeTable bin = binCalendar[cnt];
            log_v("Entry %d: %c %02d/%02d/%02d", cnt, bin.binType, bin.binYear, bin.binMonth, bin.binMonthDate);
        }
        log_v("End of Calendar");
#endif
    } else {
        log_e("Cannot find a file called 'bindates.txt'");
        return false;
    }

    // All done
    return true;
}
} // namespace data