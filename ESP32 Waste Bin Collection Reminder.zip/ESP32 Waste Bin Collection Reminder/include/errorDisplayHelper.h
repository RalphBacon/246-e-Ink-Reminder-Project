#pragma once
/*
    Put error messages on screen / on SD card.
*/
#pragma once
