#include "Arduino.h"
#include "globals.h"
#include "dataHelper.h"
#include "eInkHelper.h"
#include "WiFiHelper.h"
#include "calendarHelper.h"
#include "testHelper.h"

// Date testing (1=on, anything else but not blank = off)
#define TESTMODE 0

void setup() {
    Serial.begin(115200);

    // Read SD card/LittleFS into an array (bin collection dates)
    if (!data::populateCalendarArray()) {
        log_e("Unable to populate calendar array.");
        eInk::eInkPaperPrinting(true);
        wifi::goToSleep(true);
    }

    // Start WiFi (keep as short as is required)
    bool wifiSuccess = wifi::setupWiFi();
    if (!wifiSuccess) {
        if (globals::fatalError) {
            log_e("Unable to connect to WiFi/Get current date & time. Next attempt soon.");
            eInk::eInkPaperPrinting(true);
            wifi::goToSleep(true);
        }
    }

// For testing we can just keep inputting new "today's" date and see what pops out
#if TESTMODE == 1
    for (;;) {

        // Get test input date
        setTestCurrentDate();
#endif
        // Get next collection date for each bin type
        calendar::getNextCollectionDay('P');
        calendar::getNextCollectionDay('B');
        calendar::getNextCollectionDay('G');

#if TESTMODE == 0
        // Power saving by switching off WiFi
        wifi::switchOffWiFi();
#endif
        // Display the data
        eInk::eInkPaperPrinting(false);

#if TESTMODE == 1
    }
#endif
    // Everything except RTC is off
    wifi::goToSleep(false);
}

void loop() {
    // don't do anything! Never gets here.
}
