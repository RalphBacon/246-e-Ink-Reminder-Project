#include "globals.h"
#include "calendarHelper.h"

void setTestCurrentDate() {
    // Get override current date/time (to allow for different bin collection dates)
    int testYear, testMonth, testDay;
    char dateBuffer[5] = {0};

    // Prevent serial timeout - yes, required
    Serial.setTimeout(1000000ul);

    Serial.print("\n------------------\nEnter curr year: ");
    Serial.readBytes(dateBuffer, 2);
    testYear = atoi(dateBuffer);
    //log_d("\nEntered year is %d", testYear);

    Serial.print("\nEnter curr month: ");
    Serial.readBytes(dateBuffer, 2);
    testMonth = atoi(dateBuffer);
    //log_d("\nEntered month is %d", testMonth);

    Serial.print("\nEnter curr day: ");
    Serial.readBytes(dateBuffer, 2);
    testDay = atoi(dateBuffer);
    //log_d("\nEntered day is %d", testDay);

    // Initialise timeinfo with valid current date
    getLocalTime(&calendar::timeinfo);

    // Adjust the actual date as required
    calendar::timeinfo.tm_mday = testDay;         // Day is 1 - 31
    calendar::timeinfo.tm_mon  = testMonth - 1;   // Month is 0 - 11
    calendar::timeinfo.tm_year = testYear - 1900; // Year is minus 1900
    calendar::timeinfo.tm_hour = 0;
    calendar::timeinfo.tm_min  = 0;

    // Convert/update the date information to that entered
    mktime(&calendar::timeinfo);
    calendar::printLocalTime();
}