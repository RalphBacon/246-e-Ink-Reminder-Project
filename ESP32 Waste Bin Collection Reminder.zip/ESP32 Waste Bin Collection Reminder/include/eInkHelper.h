#pragma once
#include "Arduino.h"
#include "globals.h"
#include "calendarHelper.h"

#include "Fonts/FreeSansBold24pt7b.h"
#include "Fonts/FreeSansBold12pt7b.h"
#include "Fonts/FreeSansBold9pt7b.h"
#include "Fonts/FreeSans9pt7b.h"

namespace eInk {

/* Using 2.13" tricolor EPD */
Adafruit_IL0373 display(212, 104, EPD_DC, EPD_RESET, EPD_CS, SRAM_CS, EPD_BUSY);

// We have only two real colours (other one is white-ish)
#define COLOR1 EPD_BLACK
#define COLOR2 EPD_RED
#define HEADING_BASELINE 16

// pixels from LHS of screen to print the days until next collection (eg 12)
#define blackDaysUntilCollectionOffset 5
#define greenDaysUntilCollectionOffset 80
#define purpleDaysUntilCollectionOffset 155

// Pixels from LHS of screen to print the weekday (eg MONDAY)
#define blackWeekDayOffset 15
#define greenWeekDayOffset 88
#define purpleWeekDayOffset 158

// Pixles from LHS of screen to print month date (eg 27 DEC)
#define blackMonthOffset 3
#define greenMonthOffset 75
#define purpleMonthOffset 147

// Prints the Day/Date under the day count
void printBinCollectionDate(calendar::binNextCollection &thisCollection) {
    // How far from the left hand side of screen to print?
    int weekdayOffset = 0, monthOffset = 0;
    switch (thisCollection.binType) {
        case 'B':
            weekdayOffset = blackWeekDayOffset;
            monthOffset   = blackMonthOffset;
            break;
        case 'G':
            weekdayOffset = greenWeekDayOffset;
            monthOffset   = greenMonthOffset;
            break;
        case 'P':
            weekdayOffset = purpleWeekDayOffset;
            monthOffset   = purpleMonthOffset;
            break;
    }

    // Default (small) font initially
    display.setFont();

    // Non-standard collection day? Make it highlighted red
    if (thisCollection.binCollectionWeekDay != COLLECTION_DAY) {
        display.setTextColor(EPD_RED);
    } else {
        display.setTextColor(EPD_BLACK);
    }

    // Print the weekday
    display.setCursor(weekdayOffset, 70);
    display.print(calendar::daysOfWeek[thisCollection.binCollectionWeekDay]);

    // Date example: 18 MAR (2 digit (leading space) date, 3 letter month)
    display.setFont(&FreeSans9pt7b);
    display.setCursor(monthOffset, 91);

    // Buffer for the formatted string 25 JUN
    char buffer[10];
    snprintf(buffer, 25, "%2d %s", thisCollection.binCollectionMonthDate, calendar::months[thisCollection.binCollectionMonth - 1]);
    display.print(buffer);
}

// Bin headings (Green, Black....)
void printBinHeadings() {
    display.setFont(&FreeSansBold9pt7b);
    display.setTextSize(1);
    display.setTextColor(EPD_BLACK, EPD_WHITE);

    // Black heading
    display.setCursor(10, HEADING_BASELINE);
    display.print(BLACK_BIN_HDR);

    // Green heading
    display.setCursor(80, HEADING_BASELINE);
    display.print(GREEN_BIN_HDR);

    // Purple heading
    display.setCursor(152, HEADING_BASELINE);
    display.print(PURPLE_BIN_HDR);
}

// Various lines and blocks
void printBoilerPlateText() {
    // Heading rectangular banner
    display.fillRect(0, 0, 212, 20, EPD_WHITE);

    // Various box lines (horizontal under numbers)
    display.drawLine(0, 66, 212, 66, EPD_BLACK);

    // Vertical lines between bins
    display.drawLine(70, 0, 70, 94, EPD_BLACK);
    display.drawLine(145, 0, 145, 94, EPD_BLACK);

    // Box line under heading text
    display.drawLine(0, 20, 212, 20, EPD_BLACK);

    // Horizontal line above "last updated" string
    display.drawLine(0, 94, 212, 94, EPD_BLACK);
}

// Days until collection two-digits, large
void printDaysUntilCollection(calendar::binNextCollection &thisBinCollection) {

    // Large, easy-to-read black font
    display.setFont(&FreeSansBold24pt7b);
    display.setTextSize(1);

    // Pixels from left hand side of screen to print the number
    uint8_t daysUntilCollectionOffset = 0;
    uint8_t monthOffset               = 0;
    switch (thisBinCollection.binType) {
        case 'B':
            daysUntilCollectionOffset = blackDaysUntilCollectionOffset;
            monthOffset               = blackMonthOffset;
            break;
        case 'G':
            daysUntilCollectionOffset = greenDaysUntilCollectionOffset;
            monthOffset               = greenMonthOffset;
            break;
        case 'P':
            daysUntilCollectionOffset = purpleDaysUntilCollectionOffset;
            monthOffset               = purpleMonthOffset;
            break;
    }

    // If collection is imminent, print in red
    if (thisBinCollection.daysUntilCollection < 3) {
        display.setTextColor(EPD_RED);
    } else {
        display.setTextColor(EPD_BLACK);
    }

    // Allows two digit displays plys trailing null
    char displayBuffer[3] = {0};

    // Print days, or "NOW" if today
    if (thisBinCollection.daysUntilCollection == 0) {
        display.setCursor(monthOffset, 53);
        display.setFont(&FreeSansBold12pt7b);
        display.print("NOW");
    } else {
        display.setCursor(daysUntilCollectionOffset, 60);
        snprintf(displayBuffer, 3, "%02d", thisBinCollection.daysUntilCollection);
        display.print(displayBuffer);
    }
}

// Fatal error has occurred. Leave screen as-is, just update status line
void printFatalErrorInfo() {
    // The message, White on Black
    display.setCursor(0, 102);
    display.setFont();
    display.setTextSize(1);
    display.setTextColor(EPD_WHITE, EPD_BLACK);
    display.print("    FATAL ERROR. NEXT RETRY SOON.   ");

    // Filler line above status text. X, Y, X, Y, Colour
    display.drawLine(0, 95, 212, 95, EPD_BLACK);
    display.display();
}

// All the display stuff when calculations are completed
void eInkPaperPrinting(bool isFatalError) {
    log_d("Initialising eInk display");
    display.begin(true);
    display.clearBuffer();
    display.setTextWrap(false);

    // Boilerplate lines & text
    log_v("Printing boiler plate text");
    printBoilerPlateText();

    // Print headings
    log_v("Printing bin headings");
    printBinHeadings();

    // Fatal error just updates status line
    if (isFatalError) {
        printFatalErrorInfo();
        return;
    }

    // Print the days until collection
    log_v("Printing days until next collection");
    printDaysUntilCollection(calendar::BlackCollection);
    printDaysUntilCollection(calendar::GreenCollection);
    printDaysUntilCollection(calendar::PurpleCollection);

    // Bin collection dates (18 MAR) under the days
    log_v("Printing collection date (day/month) of next collection");
    printBinCollectionDate(calendar::BlackCollection);
    printBinCollectionDate(calendar::GreenCollection);
    printBinCollectionDate(calendar::PurpleCollection);

    // Last Update info, bottom line of screen
    log_v("Printing 'last updated date/time'");
    display.setCursor(18, 102);
    display.setFont();
    display.setTextSize(1);
    display.setTextColor(EPD_RED);
    display.print(calendar::currentDateTime);

    // All done
    log_v("Requesting update on display");
    display.display();
}
} // namespace eInk